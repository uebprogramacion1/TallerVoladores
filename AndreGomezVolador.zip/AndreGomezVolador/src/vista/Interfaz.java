package vista;

import javax.swing.JOptionPane;

public class Interfaz {
	public void cadena(String cadena) {
		JOptionPane.showMessageDialog(null, cadena);
	}

}
