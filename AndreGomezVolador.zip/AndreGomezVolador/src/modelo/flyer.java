package modelo;

public interface flyer {
	
	public abstract String takeoff();
	public abstract String land();
	public abstract String fly();
	
	

}
