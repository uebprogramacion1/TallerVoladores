package modelo;

public class kryptonian extends animal{

	public kryptonian() {
		// TODO Auto-generated constructor stub
	}
	
	public String eat() {
		
		return "es kriptiniano";
	}
	

}
