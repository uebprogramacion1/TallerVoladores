package modelo;

public class helicopter extends AirPlane {

	public helicopter() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String takeoff() {
		// TODO Auto-generated method stub
		return " el helicoptero despega";
	}

	@Override
	public String land() {
		// TODO Auto-generated method stub
		return "el helicoptero aterriza";
	}

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return " el helicoptero vuela";
	}
	
	

}
