package modelo;

public class animal {

	public animal() {
		// TODO Auto-generated constructor stub
	}
	public String eat() {
		return " el ave come";
		
	}

}
